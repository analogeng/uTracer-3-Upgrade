
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f3xx_hal.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;


PCD_HandleTypeDef hpcd_USB_FS;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USB_PCD_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_NVIC_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */

int array[144] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};
int letterA[8] = {1,1,1,1,1,0,1,0};
int letterC[8] = {1,0,1,1,0,0,0,1};
int letterS[8] = {0,1,1,1,0,0,1,1};
int letterG[8] = {1,1,1,1,0,0,1,1};
int letterH1[8] = {1,1,1,0,1,0,1,0};
int letterH2[8] = {1,1,1,0,1,1,1,0};
int null[8] = {0,1,0,0,0,0,0,0};


int debounceArray2[27] = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
int debounceArray[27] = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
int inputArray[27] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int inputAck[27] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

int display[7] = {1,2,3,4,5,6,7};

//encoder positions
int pin1encoderPos = 7;
int pin2encoderPos = 7;
int pin3encoderPos = 7;
int pin4encoderPos = 7;
int pin5encoderPos = 7;
int pin6encoderPos = 7;
int pin7encoderPos = 7;
int pin8encoderPos = 7;
int pin9encoderPos = 7;

long blink = 0;
int switch_num;
int count;
int blinkArray[9] = {0,0,0,0,0,0,0,0,0};

int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USB_PCD_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();

  /* Initialize interrupts */
  MX_NVIC_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  //write all zeroes out to clear any initial start up behavior
  	//writeArray();
  	updateUI(1,7);
  	updateUI(2,7);
  	updateUI(3,7);
  	updateUI(4,7);
  	updateUI(5,7);
  	updateUI(6,7);
  	updateUI(7,7);
  	updateUI(8,7);
  	updateUI(9,7);

  	//writeArray();

  	HAL_TIM_Base_Start_IT(&htim2);
  	HAL_TIM_Base_Start_IT(&htim3);

  while (1)
  {

	  //VALUE LIST
	 	  		//1 = A
	 	  		//2 = S
	 	  		//3 = C
	 	  		//4 = H1
	 	  		//5 = H2
	 	  		//6 = G
	 	  	  	//7 = null
	  	  	  	//8 = nothing

	 	  		//Read all of the input switches
	 /*
	 	  		inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	 	  		inputArray[1] = HAL_GPIO_ReadPin(GPIOB, S2_Pin);
	 	  		inputArray[2] = HAL_GPIO_ReadPin(GPIOB, S3_Pin);
	 	  		inputArray[3] = HAL_GPIO_ReadPin(GPIOB, S4_Pin);
	 	  		inputArray[4] = HAL_GPIO_ReadPin(GPIOB, S5_Pin);
	 	  		inputArray[5] = HAL_GPIO_ReadPin(GPIOB, S6_Pin);
	 	  		inputArray[6] = HAL_GPIO_ReadPin(GPIOB, S7_Pin);
	 	  		inputArray[7] = HAL_GPIO_ReadPin(GPIOB, S8_Pin);
	 	  		inputArray[8] = HAL_GPIO_ReadPin(GPIOC, S9_Pin);
	 */

	 	  		if(inputArray[0] == 1)
	 	  		{

	 	  			switch1Press();

	 	  		}
	 	  		if(inputArray[1] == 1)
	 	  		{

	 	  			switch2Press();

	 	  		}
	 	  		if(inputArray[2] == 1)
	 	  		{

	 	  			switch3Press();

	 	  		}
	 	  		if(inputArray[3] == 1)
	 	  		{

	 	  			switch4Press();

	 	  		}
	 	  		if(inputArray[4] == 1)
	 	  		{

	 	  			switch5Press();

	 	  		}
	 	  		if(inputArray[5] == 1)
	 	  		{

	 	  			switch6Press();

	 	  		}
	 	  		if(inputArray[6] == 1)
	 	  		{

	 	  			switch7Press();

	 	  		}
	 	  		if(inputArray[7] == 1)
	 	  		{

	 	  			switch8Press();

	 	  		}
	 	  		if(inputArray[8] == 1)
	 	  		{

	 	  			switch9Press();

	 	  		}



	 	  		//commit the changes to the array
	 	  		//writeArray();
	   }
	   /* USER CODE END 3 */

	 }
	 void updateUI(int pin, int value)
	 {
	 	//VALUE LIST
	 	//1 = A
	 	//2 = S
	 	//3 = C
	 	//4 = H1
	 	//5 = H2
	 	//6 = G
	 	int i = 8;
	 	switch(value)
	 	{
	 		case 1:
	 			while(i>0)
	 			{
	 				array[71+(pin-1)*8+i] = letterA[i-1];

	 				i--;
	 			}
	 		break;

	 		case 2:
	 			while(i>0)
	 			{
	 				array[71+(pin-1)*8+i] = letterS[i-1];

	 				i--;
	 			}
	 		break;

	 		case 3:
	 			while(i>0)
	 			{
	 				array[71+(pin-1)*8+i] = letterC[i-1];

	 				i--;
	 			}
	 		break;

	 		case 4:
	 			while(i>0)
	 			{
	 				array[71+(pin-1)*8+i] = letterH1[i-1];

	 				i--;
	 			}
	 		break;

	 		case 5:
	 			while(i>0)
	 			{
	 				array[71+(pin-1)*8+i] = letterH2[i-1];

	 				i--;
	 			}
	 		break;

	 		case 6:
	 			while(i>0)
	 			{
	 				array[71+(pin-1)*8+i] = letterG[i-1];

	 				i--;
	 			}
	 		break;

	 		case 7:
	 			while(i>0)
	 			{
	 				array[71+(pin-1)*8+i] = null[i-1];
	 				i--;
	 			}
	 		break;

	 		case 8:
	 			while(i>0)
	 			{
	 				array[71+(pin-1)*8+i] = 0;
	 				i--;
	 			}
	 		break;
	 	}

	 }

	 void updateRelay(int pin, int value)

	 {
	 	//VALUE LIST
	 	//1 = A
	 	//2 = S
	 	//3 = C
	 	//4 = H1
	 	//5 = H2
	 	//6 = G
	 	array[(pin*8)-1] = 0;
	 	array[(pin*8)-2] = 0;
	 	array[(pin*8)-3] = 0;
	 	array[(pin*8)-4] = 0;
	 	array[(pin*8)-5] = 0;
	 	array[(pin*8)-6] = 0;
	 		switch(value)
	 		{
	 			case 1:
	 				array[(pin*8)-1] = 1;
	 			break;

	 			case 2:
	 				array[(pin*8)-2] = 1;
	 			break;

	 			case 3:
	 				array[(pin*8)-3] = 1;
	 			break;

	 			case 4:
	 				array[(pin*8)-5] = 1;
	 			break;

	 			case 5:
	 				array[(pin*8)-6] = 1;
	 			break;

	 			case 6:
	 				array[(pin*8)-4] = 1;
	 			break;

	 			case 7:

	 			break;
	 		}

	 }

	 void switch1Press()
	 {

	 	inputAck[0] = 1;
	 	blinkArray[0] = 1;
	 	while(inputArray[0] == 1)
	 	{

	 	}
	 	//encoder directon 0 = CCW / 1 = CW
	 	int dir = 0;
	 	//read in the encoder position to set the default
	 	int enc2 = HAL_GPIO_ReadPin(GPIOA, A1_Pin);
	 	int enc1 = HAL_GPIO_ReadPin(GPIOA, B1_Pin);
	 	int encoder0PinALast = enc1;
	 	//VALUE LIST
	 	//1 = A
	 	//2 = S
	 	//3 = C
	 	//4 = H1
	 	//5 = H2
	 	//6 = G
	 	//do a loop of checking the encoder position and waiting for the encoder switch to break out
	 	while(1)
	 	{
	 		//check if the switch has been pressed
	 		if(inputArray[0] == 1)
	 		{
	 			inputAck[0] = 1;
	 			updateRelay(1,pin1encoderPos);
	 			//wait for the release
	 			while(inputArray[0] == 1)
	 			{
	 				//inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	 			}
	 			//get out of the function
	 			updateUI(1,pin1encoderPos);
	 			blinkArray[0] = 0;
	 			blink = 0;
	 			break;
	 		}

	 		//read in the encoder position
	 		enc2 = HAL_GPIO_ReadPin(GPIOA, A1_Pin);
	 		enc1 = HAL_GPIO_ReadPin(GPIOA, B1_Pin);

	 		//do some logic to determine the direction
	 		  if ((encoder0PinALast == 0) && (enc1 == 1))
	 		  {
	 		    if (enc2 == 0)
	 		    {
	 		    	if(pin1encoderPos == 1)
	 		    	{
	 		    		pin1encoderPos = 7;
	 		    		updateUI(1,pin1encoderPos);
	 		    	}
	 		    	else
	 		    	{
	 		    		pin1encoderPos--;
	 		    		updateUI(1,pin1encoderPos);
	 		    	}
	 		    }
	 		    else
	 		    {
	 		    	if(pin1encoderPos == 7)
	 		    	{
	 		    		pin1encoderPos = 1;
	 		    		updateUI(1,pin1encoderPos);
	 		    	}
	 		    	else
	 		    	{
	 		    		pin1encoderPos++;
	 		    		updateUI(1,pin1encoderPos);
	 		    	}
	 		    }

	 		  }
	 		  encoder0PinALast = enc1;
	 	}
	 }

	 void switch2Press()
		 {

		 	inputAck[1] = 1;
		 	blinkArray[1] = 1;
		 	while(inputArray[1] == 1)
		 	{

		 	}
		 	//encoder directon 0 = CCW / 1 = CW
		 	int dir = 0;
		 	//read in the encoder position to set the default
		 	int enc2 = HAL_GPIO_ReadPin(GPIOA, A2_Pin);
		 	int enc1 = HAL_GPIO_ReadPin(GPIOA, B2_Pin);
		 	int encoder0PinALast = enc1;
		 	//VALUE LIST
		 	//1 = A
		 	//2 = S
		 	//3 = C
		 	//4 = H1
		 	//5 = H2
		 	//6 = G
		 	//do a loop of checking the encoder position and waiting for the encoder switch to break out
		 	while(1)
		 	{
		 		//check if the switch has been pressed
		 		if(inputArray[1] == 1)
		 		{
		 			inputAck[1] = 1;
		 			updateRelay(2,pin2encoderPos);
		 			//wait for the release
		 			while(inputArray[1] == 1)
		 			{
		 				//inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
		 			}
		 			//get out of the function
		 			updateUI(2,pin2encoderPos);
		 			blinkArray[1] = 0;
		 			blink = 0;
		 			break;
		 		}

		 		//read in the encoder position
		 		enc2 = HAL_GPIO_ReadPin(GPIOA, A2_Pin);
		 		enc1 = HAL_GPIO_ReadPin(GPIOA, B2_Pin);

		 		//do some logic to determine the direction
		 		  if ((encoder0PinALast == 0) && (enc1 == 1))
		 		  {
		 		    if (enc2 == 0)
		 		    {
		 		    	if(pin2encoderPos == 1)
		 		    	{
		 		    		pin2encoderPos = 7;
		 		    		updateUI(2,pin2encoderPos);
		 		    	}
		 		    	else
		 		    	{
		 		    		pin2encoderPos--;
		 		    		updateUI(2,pin2encoderPos);
		 		    	}
		 		    }
		 		    else
		 		    {
		 		    	if(pin2encoderPos == 7)
		 		    	{
		 		    		pin2encoderPos = 1;
		 		    		updateUI(2,pin2encoderPos);
		 		    	}
		 		    	else
		 		    	{
		 		    		pin2encoderPos++;
		 		    		updateUI(2,pin2encoderPos);
		 		    	}
		 		    }

		 		  }
		 		  encoder0PinALast = enc1;
		 	}
		 }

	 void switch3Press()

	 		 {

	 		 	inputAck[2] = 1;
	 		 	blinkArray[2] = 1;
	 		 	while(inputArray[2] == 1)
	 		 	{

	 		 	}
	 		 	//encoder directon 0 = CCW / 1 = CW
	 		 	int dir = 0;
	 		 	//read in the encoder position to set the default
	 		 	int enc2 = HAL_GPIO_ReadPin(GPIOA, A3_Pin);
	 		 	int enc1 = HAL_GPIO_ReadPin(GPIOA, B3_Pin);
	 		 	int encoder0PinALast = enc1;
	 		 	//VALUE LIST
	 		 	//1 = A
	 		 	//2 = S
	 		 	//3 = C
	 		 	//4 = H1
	 		 	//5 = H2
	 		 	//6 = G
	 		 	//do a loop of checking the encoder position and waiting for the encoder switch to break out
	 		 	while(1)
	 		 	{
	 		 		//check if the switch has been pressed
	 		 		if(inputArray[2] == 1)
	 		 		{
	 		 			inputAck[2] = 1;
	 		 			updateRelay(3,pin3encoderPos);
	 		 			//wait for the release
	 		 			while(inputArray[2] == 1)
	 		 			{
	 		 				//inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	 		 			}
	 		 			//get out of the function
	 		 			updateUI(3,pin3encoderPos);
	 		 			blinkArray[2] = 0;
	 		 			blink = 0;
	 		 			break;
	 		 		}

	 		 		//read in the encoder position
	 		 		enc2 = HAL_GPIO_ReadPin(GPIOA, A3_Pin);
	 		 		enc1 = HAL_GPIO_ReadPin(GPIOA, B3_Pin);

	 		 		//do some logic to determine the direction
	 		 		  if ((encoder0PinALast == 0) && (enc1 == 1))
	 		 		  {
	 		 		    if (enc2 == 0)
	 		 		    {
	 		 		    	if(pin3encoderPos == 1)
	 		 		    	{
	 		 		    		pin3encoderPos = 7;
	 		 		    		updateUI(3,pin3encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin3encoderPos--;
	 		 		    		updateUI(3,pin3encoderPos);
	 		 		    	}
	 		 		    }
	 		 		    else
	 		 		    {
	 		 		    	if(pin3encoderPos == 7)
	 		 		    	{
	 		 		    		pin3encoderPos = 1;
	 		 		    		updateUI(3,pin3encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin3encoderPos++;
	 		 		    		updateUI(3,pin3encoderPos);
	 		 		    	}
	 		 		    }

	 		 		  }
	 		 		  encoder0PinALast = enc1;
	 		 	}
	 		 }

	 void switch4Press()
	 		 {

	 		 	inputAck[3] = 1;
	 		 	blinkArray[3] = 1;
	 		 	while(inputArray[3] == 1)
	 		 	{

	 		 	}
	 		 	//encoder directon 0 = CCW / 1 = CW
	 		 	int dir = 0;
	 		 	//read in the encoder position to set the default
	 		 	int enc2 = HAL_GPIO_ReadPin(GPIOA, A4_Pin);
	 		 	int enc1 = HAL_GPIO_ReadPin(GPIOA, B4_Pin);
	 		 	int encoder0PinALast = enc1;
	 		 	//VALUE LIST
	 		 	//1 = A
	 		 	//2 = S
	 		 	//3 = C
	 		 	//4 = H1
	 		 	//5 = H2
	 		 	//6 = G
	 		 	//do a loop of checking the encoder position and waiting for the encoder switch to break out
	 		 	while(1)
	 		 	{
	 		 		//check if the switch has been pressed
	 		 		if(inputArray[3] == 1)
	 		 		{
	 		 			inputAck[3] = 1;
	 		 			updateRelay(4,pin4encoderPos);
	 		 			//wait for the release
	 		 			while(inputArray[3] == 1)
	 		 			{
	 		 				//inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	 		 			}
	 		 			//get out of the function
	 		 			updateUI(4,pin4encoderPos);
	 		 			blinkArray[3] = 0;
	 		 			blink = 0;
	 		 			break;
	 		 		}

	 		 		//read in the encoder position
	 		 		enc2 = HAL_GPIO_ReadPin(GPIOA, A4_Pin);
	 		 		enc1 = HAL_GPIO_ReadPin(GPIOA, B4_Pin);

	 		 		//do some logic to determine the direction
	 		 		  if ((encoder0PinALast == 0) && (enc1 == 1))
	 		 		  {
	 		 		    if (enc2 == 0)
	 		 		    {
	 		 		    	if(pin4encoderPos == 1)
	 		 		    	{
	 		 		    		pin4encoderPos = 7;
	 		 		    		updateUI(4,pin4encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin4encoderPos--;
	 		 		    		updateUI(4,pin4encoderPos);
	 		 		    	}
	 		 		    }
	 		 		    else
	 		 		    {
	 		 		    	if(pin4encoderPos == 7)
	 		 		    	{
	 		 		    		pin4encoderPos = 1;
	 		 		    		updateUI(4,pin4encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin4encoderPos++;
	 		 		    		updateUI(4,pin4encoderPos);
	 		 		    	}
	 		 		    }

	 		 		  }
	 		 		  encoder0PinALast = enc1;
	 		 	}
	 		 }

	 void switch5Press()
	 		 {

	 		 	inputAck[4] = 1;
	 		 	blinkArray[4] = 1;
	 		 	while(inputArray[4] == 1)
	 		 	{

	 		 	}
	 		 	//encoder directon 0 = CCW / 1 = CW
	 		 	int dir = 0;
	 		 	//read in the encoder position to set the default
	 		 	int enc2 = HAL_GPIO_ReadPin(GPIOA, A5_Pin);
	 		 	int enc1 = HAL_GPIO_ReadPin(GPIOA, B5_Pin);
	 		 	int encoder0PinALast = enc1;
	 		 	//VALUE LIST
	 		 	//1 = A
	 		 	//2 = S
	 		 	//3 = C
	 		 	//4 = H1
	 		 	//5 = H2
	 		 	//6 = G
	 		 	//do a loop of checking the encoder position and waiting for the encoder switch to break out
	 		 	while(1)
	 		 	{
	 		 		//check if the switch has been pressed
	 		 		if(inputArray[4] == 1)
	 		 		{
	 		 			inputAck[4] = 1;
	 		 			updateRelay(5,pin5encoderPos);
	 		 			//wait for the release
	 		 			while(inputArray[4] == 1)
	 		 			{
	 		 				//inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	 		 			}
	 		 			//get out of the function
	 		 			updateUI(5,pin5encoderPos);
	 		 			blinkArray[4] = 0;
	 		 			blink = 0;
	 		 			break;
	 		 		}

	 		 		//read in the encoder position
	 		 		enc2 = HAL_GPIO_ReadPin(GPIOA, A5_Pin);
	 		 		enc1 = HAL_GPIO_ReadPin(GPIOA, B5_Pin);

	 		 		//do some logic to determine the direction
	 		 		  if ((encoder0PinALast == 0) && (enc1 == 1))
	 		 		  {
	 		 		    if (enc2 == 0)
	 		 		    {
	 		 		    	if(pin5encoderPos == 1)
	 		 		    	{
	 		 		    		pin5encoderPos = 7;
	 		 		    		updateUI(5,pin5encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin5encoderPos--;
	 		 		    		updateUI(5,pin5encoderPos);
	 		 		    	}
	 		 		    }
	 		 		    else
	 		 		    {
	 		 		    	if(pin5encoderPos == 7)
	 		 		    	{
	 		 		    		pin5encoderPos = 1;
	 		 		    		updateUI(5,pin5encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin5encoderPos++;
	 		 		    		updateUI(5,pin5encoderPos);
	 		 		    	}
	 		 		    }

	 		 		  }
	 		 		  encoder0PinALast = enc1;
	 		 	}
	 		 }

	 void switch6Press()
	 		 {

	 		 	inputAck[5] = 1;
	 		 	blinkArray[5] = 1;
	 		 	while(inputArray[5] == 1)
	 		 	{

	 		 	}
	 		 	//encoder directon 0 = CCW / 1 = CW
	 		 	int dir = 0;
	 		 	//read in the encoder position to set the default
	 		 	int enc2 = HAL_GPIO_ReadPin(GPIOA, A6_Pin);
	 		 	int enc1 = HAL_GPIO_ReadPin(GPIOC, B6_Pin);
	 		 	int encoder0PinALast = enc1;
	 		 	//VALUE LIST
	 		 	//1 = A
	 		 	//2 = S
	 		 	//3 = C
	 		 	//4 = H1
	 		 	//5 = H2
	 		 	//6 = G
	 		 	//do a loop of checking the encoder position and waiting for the encoder switch to break out
	 		 	while(1)
	 		 	{
	 		 		//check if the switch has been pressed
	 		 		if(inputArray[5] == 1)
	 		 		{
	 		 			inputAck[5] = 1;
	 		 			updateRelay(6,pin6encoderPos);
	 		 			//wait for the release
	 		 			while(inputArray[5] == 1)
	 		 			{
	 		 				//inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	 		 			}
	 		 			//get out of the function
	 		 			updateUI(6,pin6encoderPos);
	 		 			blinkArray[5] = 0;
	 		 			blink = 0;
	 		 			break;
	 		 		}

	 		 		//read in the encoder position
	 		 		enc2 = HAL_GPIO_ReadPin(GPIOA, A6_Pin);
	 		 		enc1 = HAL_GPIO_ReadPin(GPIOC, B6_Pin);

	 		 		//do some logic to determine the direction
	 		 		  if ((encoder0PinALast == 0) && (enc1 == 1))
	 		 		  {
	 		 		    if (enc2 == 0)
	 		 		    {
	 		 		    	if(pin6encoderPos == 1)
	 		 		    	{
	 		 		    		pin6encoderPos = 7;
	 		 		    		updateUI(6,pin6encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin6encoderPos--;
	 		 		    		updateUI(6,pin6encoderPos);
	 		 		    	}
	 		 		    }
	 		 		    else
	 		 		    {
	 		 		    	if(pin6encoderPos == 7)
	 		 		    	{
	 		 		    		pin6encoderPos = 1;
	 		 		    		updateUI(6,pin6encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin6encoderPos++;
	 		 		    		updateUI(6,pin6encoderPos);
	 		 		    	}
	 		 		    }

	 		 		  }
	 		 		  encoder0PinALast = enc1;
	 		 	}
	 		 }

	 void switch7Press()
	 		 {

	 		 	inputAck[6] = 1;
	 		 	blinkArray[6] = 1;
	 		 	while(inputArray[6] == 1)
	 		 	{

	 		 	}
	 		 	//encoder directon 0 = CCW / 1 = CW
	 		 	int dir = 0;
	 		 	//read in the encoder position to set the default
	 		 	int enc2 = HAL_GPIO_ReadPin(GPIOC, A7_Pin);
	 		 	int enc1 = HAL_GPIO_ReadPin(GPIOD, B7_Pin);
	 		 	int encoder0PinALast = enc1;
	 		 	//VALUE LIST
	 		 	//1 = A
	 		 	//2 = S
	 		 	//3 = C
	 		 	//4 = H1
	 		 	//5 = H2
	 		 	//6 = G
	 		 	//do a loop of checking the encoder position and waiting for the encoder switch to break out
	 		 	while(1)
	 		 	{
	 		 		//check if the switch has been pressed
	 		 		if(inputArray[6] == 1)
	 		 		{
	 		 			inputAck[6] = 1;
	 		 			updateRelay(7,pin7encoderPos);
	 		 			//wait for the release
	 		 			while(inputArray[6] == 1)
	 		 			{
	 		 				//inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	 		 			}
	 		 			//get out of the function
	 		 			updateUI(7,pin7encoderPos);
	 		 			blinkArray[6] = 0;
	 		 			blink = 0;
	 		 			break;
	 		 		}

	 		 		//read in the encoder position
	 		 		enc2 = HAL_GPIO_ReadPin(GPIOC, A7_Pin);
	 		 		enc1 = HAL_GPIO_ReadPin(GPIOD, B7_Pin);

	 		 		//do some logic to determine the direction
	 		 		  if ((encoder0PinALast == 0) && (enc1 == 1))
	 		 		  {
	 		 		    if (enc2 == 0)
	 		 		    {
	 		 		    	if(pin7encoderPos == 1)
	 		 		    	{
	 		 		    		pin7encoderPos = 7;
	 		 		    		updateUI(7,pin7encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin7encoderPos--;
	 		 		    		updateUI(7,pin7encoderPos);
	 		 		    	}
	 		 		    }
	 		 		    else
	 		 		    {
	 		 		    	if(pin7encoderPos == 7)
	 		 		    	{
	 		 		    		pin7encoderPos = 1;
	 		 		    		updateUI(7,pin7encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin7encoderPos++;
	 		 		    		updateUI(7,pin7encoderPos);
	 		 		    	}
	 		 		    }

	 		 		  }
	 		 		  encoder0PinALast = enc1;
	 		 	}
	 		 }

	 void switch8Press()
	 	 		 {

	 	 		 	inputAck[7] = 1;
	 	 		 	blinkArray[7] = 1;
	 	 		 	while(inputArray[7] == 1)
	 	 		 	{

	 	 		 	}
	 	 		 	//encoder directon 0 = CCW / 1 = CW
	 	 		 	int dir = 0;
	 	 		 	//read in the encoder position to set the default
	 	 		 	int enc2 = HAL_GPIO_ReadPin(GPIOE, A8_Pin);
	 	 		 	int enc1 = HAL_GPIO_ReadPin(GPIOE, B8_Pin);
	 	 		 	int encoder0PinALast = enc1;
	 	 		 	//VALUE LIST
	 	 		 	//1 = A
	 	 		 	//2 = S
	 	 		 	//3 = C
	 	 		 	//4 = H1
	 	 		 	//5 = H2
	 	 		 	//6 = G
	 	 		 	//do a loop of checking the encoder position and waiting for the encoder switch to break out
	 	 		 	while(1)
	 	 		 	{
	 	 		 		//check if the switch has been pressed
	 	 		 		if(inputArray[7] == 1)
	 	 		 		{
	 	 		 			inputAck[7] = 1;
	 	 		 			updateRelay(8,pin8encoderPos);
	 	 		 			//wait for the release
	 	 		 			while(inputArray[7] == 1)
	 	 		 			{
	 	 		 				//inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	 	 		 			}
	 	 		 			//get out of the function
	 	 		 			updateUI(8,pin8encoderPos);
	 	 		 			blinkArray[7] = 0;
	 	 		 			blink = 0;
	 	 		 			break;
	 	 		 		}

	 	 		 		//read in the encoder position
	 	 		 		enc2 = HAL_GPIO_ReadPin(GPIOE, A8_Pin);
	 	 		 		enc1 = HAL_GPIO_ReadPin(GPIOE, B8_Pin);

	 	 		 		//do some logic to determine the direction
	 	 		 		  if ((encoder0PinALast == 0) && (enc1 == 1))
	 	 		 		  {
	 	 		 		    if (enc2 == 0)
	 	 		 		    {
	 	 		 		    	if(pin8encoderPos == 1)
	 	 		 		    	{
	 	 		 		    		pin8encoderPos = 7;
	 	 		 		    		updateUI(8,pin8encoderPos);
	 	 		 		    	}
	 	 		 		    	else
	 	 		 		    	{
	 	 		 		    		pin8encoderPos--;
	 	 		 		    		updateUI(8,pin8encoderPos);
	 	 		 		    	}
	 	 		 		    }
	 	 		 		    else
	 	 		 		    {
	 	 		 		    	if(pin8encoderPos == 7)
	 	 		 		    	{
	 	 		 		    		pin8encoderPos = 1;
	 	 		 		    		updateUI(8,pin8encoderPos);
	 	 		 		    	}
	 	 		 		    	else
	 	 		 		    	{
	 	 		 		    		pin8encoderPos++;
	 	 		 		    		updateUI(8,pin8encoderPos);
	 	 		 		    	}
	 	 		 		    }

	 	 		 		  }
	 	 		 		  encoder0PinALast = enc1;
	 	 		 	}
	 	 		 }

	 void switch9Press()
	 		 {

	 		 	inputAck[8] = 1;
	 		 	blinkArray[8] = 1;
	 		 	while(inputArray[8] == 1)
	 		 	{

	 		 	}
	 		 	//encoder directon 0 = CCW / 1 = CW
	 		 	int dir = 0;
	 		 	//read in the encoder position to set the default
	 		 	int enc2 = HAL_GPIO_ReadPin(GPIOF, A9_Pin);
	 		 	int enc1 = HAL_GPIO_ReadPin(GPIOF, B9_Pin);
	 		 	int encoder0PinALast = enc1;
	 		 	//VALUE LIST
	 		 	//1 = A
	 		 	//2 = S
	 		 	//3 = C
	 		 	//4 = H1
	 		 	//5 = H2
	 		 	//6 = G
	 		 	//do a loop of checking the encoder position and waiting for the encoder switch to break out
	 		 	while(1)
	 		 	{
	 		 		//check if the switch has been pressed
	 		 		if(inputArray[8] == 1)
	 		 		{
	 		 			inputAck[8] = 1;
	 		 			updateRelay(9,pin9encoderPos);
	 		 			//wait for the release
	 		 			while(inputArray[8] == 1)
	 		 			{
	 		 				//inputArray[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	 		 			}
	 		 			//get out of the function
	 		 			updateUI(9,pin9encoderPos);
	 		 			blinkArray[8] = 0;
	 		 			blink = 0;
	 		 			break;
	 		 		}

	 		 		//read in the encoder position
	 		 		enc2 = HAL_GPIO_ReadPin(GPIOF, A9_Pin);
	 		 		enc1 = HAL_GPIO_ReadPin(GPIOF, B9_Pin);

	 		 		//do some logic to determine the direction
	 		 		  if ((encoder0PinALast == 0) && (enc1 == 1))
	 		 		  {
	 		 		    if (enc2 == 0)
	 		 		    {
	 		 		    	if(pin9encoderPos == 1)
	 		 		    	{
	 		 		    		pin9encoderPos = 7;
	 		 		    		updateUI(9,pin9encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin9encoderPos--;
	 		 		    		updateUI(9,pin9encoderPos);
	 		 		    	}
	 		 		    }
	 		 		    else
	 		 		    {
	 		 		    	if(pin9encoderPos == 7)
	 		 		    	{
	 		 		    		pin9encoderPos = 1;
	 		 		    		updateUI(9,pin9encoderPos);
	 		 		    	}
	 		 		    	else
	 		 		    	{
	 		 		    		pin9encoderPos++;
	 		 		    		updateUI(9,pin9encoderPos);
	 		 		    	}
	 		 		    }

	 		 		  }
	 		 		  encoder0PinALast = enc1;
	 		 	}
	 		 }
	 void writeArray(void)
	 {
	 	//pull the latch pin low
	 	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,0);
	 	//set up the data output
	 	for(int y = 144; y > 0; y--)
	 	{
	 		//toggle the data
	 		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1,array[y-1]);
	 		//toggle the clock
	 		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0,1);
	 		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0,0);
	 	}
	 	//bring the latch pin back up
	 	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,1);
	 }

	 /**
	   * @brief System Clock Configuration
	   * @retval None
	   */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV2;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.USBClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/**
  * @brief NVIC Configuration.
  * @retval None
  */
static void MX_NVIC_Init(void)
{
  /* TIM2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TIM2_IRQn);
  /* TIM3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TIM3_IRQn);
}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 7200;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM3 init function */
static void MX_TIM3_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 36000;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USB init function */
static void MX_USB_PCD_Init(void)
{

  hpcd_USB_FS.Instance = USB;
  hpcd_USB_FS.Init.dev_endpoints = 8;
  hpcd_USB_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_FS.Init.ep0_mps = DEP0CTL_MPS_64;
  hpcd_USB_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_FS.Init.battery_charging_enable = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_FS) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, CLK595_Pin|DAT595_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LAT595_GPIO_Port, LAT595_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : S9_Pin */
  GPIO_InitStruct.Pin = S9_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(S9_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : B6_Pin A7_Pin */
  GPIO_InitStruct.Pin = B6_Pin|A7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : A1_Pin B1_Pin A2_Pin B2_Pin 
                           A3_Pin B3_Pin A4_Pin B4_Pin 
                           A5_Pin B5_Pin A6_Pin */
  GPIO_InitStruct.Pin = A1_Pin|B1_Pin|A2_Pin|B2_Pin 
                          |A3_Pin|B3_Pin|A4_Pin|B4_Pin 
                          |A5_Pin|B5_Pin|A6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : CLK595_Pin DAT595_Pin */
  GPIO_InitStruct.Pin = CLK595_Pin|DAT595_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : LAT595_Pin */
  GPIO_InitStruct.Pin = LAT595_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(LAT595_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : A8_Pin B8_Pin */
  GPIO_InitStruct.Pin = A8_Pin|B8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : S7_Pin S8_Pin S1_Pin S2_Pin 
                           S3_Pin S4_Pin S5_Pin S6_Pin */
  GPIO_InitStruct.Pin = S7_Pin|S8_Pin|S1_Pin|S2_Pin 
                          |S3_Pin|S4_Pin|S5_Pin|S6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : B7_Pin */
  GPIO_InitStruct.Pin = B7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B7_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : A9_Pin B9_Pin */
  GPIO_InitStruct.Pin = A9_Pin|B9_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */
void TIM2_IRQHandler(void)
{
  /* USER CODE BEGIN TIM2_IRQn 0 */

  /* USER CODE END TIM2_IRQn 0 */
	//I DONT KNOW WHAT THIS IS....
	HAL_TIM_IRQHandler(&htim2);

	HAL_TIM_Base_Stop_IT(&htim2);

	//READ set the array to the last values
	debounceArray[0] = debounceArray2[0];
	debounceArray[1] = debounceArray2[1];
	debounceArray[2] = debounceArray2[2];
	debounceArray[3] = debounceArray2[3];
	debounceArray[4] = debounceArray2[4];
	debounceArray[5] = debounceArray2[5];
	debounceArray[6] = debounceArray2[6];
	debounceArray[7] = debounceArray2[7];
	debounceArray[8] = debounceArray2[8];
	debounceArray[9] = debounceArray2[9];
	debounceArray[10] = debounceArray2[10];
	debounceArray[11] = debounceArray2[11];
	debounceArray[12] = debounceArray2[12];
	debounceArray[13] = debounceArray2[13];
	debounceArray[14] = debounceArray2[14];
	debounceArray[15] = debounceArray2[15];
	debounceArray[16] = debounceArray2[16];
	debounceArray[17] = debounceArray2[17];
	debounceArray[18] = debounceArray2[18];
	debounceArray[19] = debounceArray2[19];
	debounceArray[20] = debounceArray2[20];
	debounceArray[21] = debounceArray2[21];
	debounceArray[22] = debounceArray2[22];
	debounceArray[23] = debounceArray2[23];
	debounceArray[24] = debounceArray2[24];
	debounceArray[25] = debounceArray2[25];
	debounceArray[26] = debounceArray2[26];

	//Bring in new values
	debounceArray2[0] = HAL_GPIO_ReadPin(GPIOB, S1_Pin);
	debounceArray2[1] = HAL_GPIO_ReadPin(GPIOB, S2_Pin);
	debounceArray2[2] = HAL_GPIO_ReadPin(GPIOB, S3_Pin);
	debounceArray2[3] = HAL_GPIO_ReadPin(GPIOB, S4_Pin);
	debounceArray2[4] = HAL_GPIO_ReadPin(GPIOB, S5_Pin);
	debounceArray2[5] = HAL_GPIO_ReadPin(GPIOB, S6_Pin);
	debounceArray2[6] = HAL_GPIO_ReadPin(GPIOB, S7_Pin);
	debounceArray2[7] = HAL_GPIO_ReadPin(GPIOB, S8_Pin);
	debounceArray2[8] = HAL_GPIO_ReadPin(GPIOC, S9_Pin);
	debounceArray2[9] = HAL_GPIO_ReadPin(GPIOB, A1_Pin);
	debounceArray2[10] = HAL_GPIO_ReadPin(GPIOB, B1_Pin);
	debounceArray2[11] = HAL_GPIO_ReadPin(GPIOB, A2_Pin);
	debounceArray2[12] = HAL_GPIO_ReadPin(GPIOB, B2_Pin);
	debounceArray2[13] = HAL_GPIO_ReadPin(GPIOB, A3_Pin);
	debounceArray2[14] = HAL_GPIO_ReadPin(GPIOB, B3_Pin);
	debounceArray2[15] = HAL_GPIO_ReadPin(GPIOB, A4_Pin);
	debounceArray2[16] = HAL_GPIO_ReadPin(GPIOB, B4_Pin);
	debounceArray2[17] = HAL_GPIO_ReadPin(GPIOC, A5_Pin);
	debounceArray2[18] = HAL_GPIO_ReadPin(GPIOB, B5_Pin);
	debounceArray2[19] = HAL_GPIO_ReadPin(GPIOB, A6_Pin);
	debounceArray2[20] = HAL_GPIO_ReadPin(GPIOB, B6_Pin);
	debounceArray2[21] = HAL_GPIO_ReadPin(GPIOB, A7_Pin);
	debounceArray2[22] = HAL_GPIO_ReadPin(GPIOB, B7_Pin);
	debounceArray2[23] = HAL_GPIO_ReadPin(GPIOB, A8_Pin);
	debounceArray2[24] = HAL_GPIO_ReadPin(GPIOB, B8_Pin);
	debounceArray2[25] = HAL_GPIO_ReadPin(GPIOB, A9_Pin);
	debounceArray2[26] = HAL_GPIO_ReadPin(GPIOC, B9_Pin);

	//do a debounce array check for a button press
	for(int count = 0; count < 27; count++)
	{
		if(debounceArray[count] == 0 && debounceArray2[count] == 0 && inputAck[count] == 0)
		{
			//set the flag indicating a button press
			inputArray[count] = 1;
		}
	}

	//Check for any ack from the main loop
	for(int count = 0; count < 27; count++)
	{
		if(debounceArray[count] == 1 && debounceArray2[count] == 1 && inputAck[count] == 1)
		{
			//clear the flag and ack
			inputArray[count] = 0;
			inputAck[count] = 0;
		}
	}




	//clear the timer flag
	__HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_UPDATE);
	HAL_TIM_Base_Start_IT(&htim2);
  /* USER CODE END TIM2_IRQn 1 */
}

void TIM3_IRQHandler(void)
{

  /* USER CODE BEGIN TIM3_IRQn 0 */

  /* USER CODE END TIM3_IRQn 0 */
  HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */
  HAL_TIM_Base_Stop_IT(&htim3);
  if(blinkArray[0] == 1)
  {

	  if(blink > 500)
	  {
		  updateUI(1,8);
		  blink++;
		  if(blink == 1000)
	  	  {
			  blink = 0;
	  	  }
	  }
	  else
	  {
		  blink++;
		  updateUI(1,pin1encoderPos);
	  }
  }
  if(blinkArray[1] == 1)
  {

	  if(blink > 500)
	  {
		  updateUI(2,8);
		  blink++;
		  if(blink == 1000)
	  	  {
			  blink = 0;
	  	  }
	  }
	  else
	  {
		  blink++;
		  updateUI(2,pin2encoderPos);
	  }
  }
  if(blinkArray[2] == 1)
  {

	  if(blink > 500)
	  {
		  updateUI(3,8);
		  blink++;
		  if(blink == 1000)
	  	  {
			  blink = 0;
	  	  }
	  }
	  else
	  {
		  blink++;
		  updateUI(3,pin3encoderPos);
	  }
  }
  if(blinkArray[3] == 1)
  {

	  if(blink > 500)
	  {
		  updateUI(4,8);
		  blink++;
		  if(blink == 1000)
	  	  {
			  blink = 0;
	  	  }
	  }
	  else
	  {
		  blink++;
		  updateUI(4,pin4encoderPos);
	  }
  }
  if(blinkArray[4] == 1)
  {

	  if(blink > 500)
	  {
		  updateUI(5,8);
		  blink++;
		  if(blink == 1000)
	  	  {
			  blink = 0;
	  	  }
	  }
	  else
	  {
		  blink++;
		  updateUI(5,pin5encoderPos);
	  }
  }
  if(blinkArray[5] == 1)
  {

	  if(blink > 500)
	  {
		  updateUI(6,8);
		  blink++;
		  if(blink == 1000)
	  	  {
			  blink = 0;
	  	  }
	  }
	  else
	  {
		  blink++;
		  updateUI(6,pin6encoderPos);
	  }
  }
  if(blinkArray[6] == 1)
  {

	  if(blink > 500)
	  {
		  updateUI(7,8);
		  blink++;
		  if(blink == 1000)
	  	  {
			  blink = 0;
	  	  }
	  }
	  else
	  {
		  blink++;
		  updateUI(7,pin7encoderPos);
	  }
  }
  if(blinkArray[7] == 1)
  {

	  if(blink > 500)
	  {
		  updateUI(8,8);
		  blink++;
		  if(blink == 1000)
	  	  {
			  blink = 0;
	  	  }
	  }
	  else
	  {
		  blink++;
		  updateUI(8,pin8encoderPos);
	  }
  }
  if(blinkArray[8] == 1)
  {

	  if(blink > 500)
	  {
		  updateUI(9,8);
		  blink++;
		  if(blink == 1000)
	  	  {
			  blink = 0;
	  	  }
	  }
	  else
	  {
		  blink++;
		  updateUI(9,pin9encoderPos);
	  }
  }


  writeArray();

  __HAL_TIM_CLEAR_FLAG(&htim3, TIM_FLAG_UPDATE);
  HAL_TIM_Base_Start_IT(&htim3);

  /* USER CODE END TIM3_IRQn 1 */
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
